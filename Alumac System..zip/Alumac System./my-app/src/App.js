import './App.css';
import MainHome from './Pages/MainHome';
import {Route,Routes} from 'react-router-dom'
import MainAboutUs from './Pages/MainAboutUs';
import MainProduct from './Pages/MainProduct';
import MainOurClient from './Pages/MainOurClient';
import MainContactUs from './Pages/MainContactUs';
import Data from './Data/Data';
function App() {
  return (
     
    <div className="App">
      <Routes>
        <Route exact path="/" element={<MainHome producShow={6} clientShow={3}/>} />
        <Route exact path="/home" element={<MainHome producShow={6} clientShow={3}/>} />
        <Route exact path="/aboutUs" element={<MainAboutUs />} />
        <Route exact path="/product" element={<MainProduct producShow={Data.product.length}/>} />
        <Route exact path="/client" element={<MainOurClient clientShow={Data.clientData.length}/>} />
        <Route exact path="/contact" element={<MainContactUs />} />
      </Routes>
    </div>
      
  );
}

export default App;
