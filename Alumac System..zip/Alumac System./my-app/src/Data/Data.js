
let Data = {
    "webLogo" : './img/hospital-bed.png',
    "homeData" : [
        {
            'key' : 1,
            'img' : 'https://images.pexels.com/photos/6510382/pexels-photo-6510382.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
            'title' : 'Alumac System Company',
            'description' : `Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quos suscipit voluptatem sequi quae. Soluta, consequatur? Consectetur quis magni, possimus repudiandae odio atque aperiam distinctio provident quasi, at corrupti molestiae quaerat! Voluptate sed velit laboriosam reiciendis nostrum unde quam itaque porro.`,
            'button' : 'View More.',
            'path' : 'aboutUs'
        },{
            'key' : 2,
            'img' : 'https://images.pexels.com/photos/10049938/pexels-photo-10049938.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
            'title' : 'Morden Hospital Equipments',
            'description' : `Lorem ipsum dolor sit amet consectetur, adipisicing elit. Mollitia cum in vel voluptatibus, a quis sequi magni quo iusto dolor maxime non beatae recusandae perferendis! Necessitatibus odit animi eaque voluptatem qui architecto incidunt iure sapiente non vitae quis, odio perferendis!`,
            'path' : 'product'
        },{
            'key' : 3,
            'img' : 'https://images.pexels.com/photos/4094199/pexels-photo-4094199.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
            'title' : 'Best Hospital Furnitures',
            'description' : `Lorem ipsum dolor sit, amet consectetur adipisicing elit. Repudiandae perferendis numquam incidunt vel unde eos excepturi alias dolorum neque harum ut reiciendis libero, quidem eum consequuntur asperiores eius necessitatibus molestiae omnis? Soluta libero sequi et esse labore! Rerum, doloremque ipsam.`,
            'path' : 'product'
        }
    ],
    "aboutUs" : {
        "companyImg" : "https://images.pexels.com/photos/188035/pexels-photo-188035.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260",
        'owner' : "https://images.pexels.com/photos/6737848/pexels-photo-6737848.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260",
        "ownerName" : 'Amit Yadav',
        "aboutDataPara1" : `
        HEMC (Hospital Equipment Manufacturing Company) was established in the year 1981 and has since been engaged in the export of Medical equipments, Hospital equipments, Orthopaedic Implants & instruments, Laboratory equipments, Scientific & Educational products worldwide. Your support has made us a "Government of India" recognised export house. Our goods have reached all continents from "The Americas" to "Europe" and beyond…
        
        With 100+ employees who are involved in activities related to production, inspections and dispatch we assure you world class healthcare products delivered to your doorstep. Each employee has in-depth knowledge about the product and has years of experience to back that knowledge.
        Our new website offers a multi dimensional experience into our product range. This has been designed for your convenience so that you make HEMC your "ONE STOP SHOP" for all your Medical requirements. The product range includes Orthopaedic Implants, Hospital Hollow wares, Resuscitators, Laryngoscopes, Hospital Furniture, Rehabilitation Aids, Autoclaves, Sterilizers, Suction Machines and many more.
        
        `,
        "aboutDataPara2" : `We offer you a complete experience starting from the placement of your order until the successful installation of the product. The logistics department makes sure that your goods reach you with the best available carriers in the shortest possible time frame. Our post-sales customer service team is available 24/7 to answer all your queries regarding our products.

        Customers based in developed Countries such as Europe, America and Canada get their products manufactured from us under their OEM brands and then re-distribute them to Africa, Latin & Central America. This has been possible with certifications like CE, FDA, GMP & ISO which in turn has become mandatory for exporting to these countries. After manufacturing and a series of inspections by our QC department, the HEMC hologram is placed on the product. This product is then our guarantee for a quality product.
        
        Our marketing team has made its presence felt by travelling extensively to over 60 countries to meet existing distributors or appoint new ones. Once a country distributor is appointed, we then make it a point to visit that company at least once a year. This is done with a view of introducing new product ranges as well as to strengthen ties.
        
        Our company has maintained a standard policy of keeping the quality universal for all customers. Unlike some of our competitors here in India who chose to neglect quality while distributing goods especially to developing nations.
        
        We thank you for all your support and look forward to serving you in the near future.`
    },
    "serviceData" : [
        {
            "value" : 'a',
            'img':'./img/fast Delivery.svg',
            'title' : 'Fast Delivery',
            'description' : 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Recusandae nostrum dolores facilis rerum consequuntur.'
        }, {
            "value" : 'b',
            'img':'./img/free Shipping.svg',
            'title' : 'Free Shipping',
            'description' : 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Recusandae nostrum dolores facilis rerum consequuntur.'
        }, {
            "value" : 'b',
            'img':'./img/best Quality.svg',
            'title' : 'Best Quality',
            'description' : 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Recusandae nostrum dolores facilis rerum consequuntur.'
        }
    ],
    "newArrivel" : [
        "https://i02.appmifile.com/561_operator_in/16/01/2022/a3dd2975ea8b7659a7e2dc54086001d5.jpg",
        "https://i02.appmifile.com/671_operator_in/16/01/2022/9545f9abd349a6beaf7a6c3dd5a46c09.jpg",
        "https://i02.appmifile.com/720_operator_in/16/01/2022/36053f55068d74553a6896eca7713ea5.jpg",
        "https://i02.appmifile.com/503_operator_in/16/01/2022/0da5bb03ca0285baffc7204e9d687cc5.jpg",
        "https://i02.appmifile.com/806_operator_in/16/01/2022/c6456d7218a33940327733eddd1873e0.jpg",
        "https://i02.appmifile.com/949_operator_in/16/01/2022/3ad4c453430cf385f71fd577fc23fc1a.jpg",
    ],
    "product" : [
        {
            "proName" : "produc1",
            "proPrice" : "₹2,000",
            "proDec" : "If you cannot provide a valid href, but still need the element to resemble a link,",
            "proImg" : "https://www.birkovaproducts.com/product_images/uploaded_images/surgery-room.png",
            "onHomePage" : 'product'
        },
        {
            "proName" : "produc1",
            "proPrice" : "₹2,000",
            "proDec" : "If you cannot provide a valid href, but still need the element to resemble a link,",
            "proImg" : "https://www.birkovaproducts.com/product_images/uploaded_images/surgery-room.png",
            "onHomePage" : 'product'
        },
        {
            "proName" : "produc1",
            "proPrice" : "₹2,000",
            "proDec" : "If you cannot provide a valid href, but still need the element to resemble a link,",
            "proImg" : "https://www.birkovaproducts.com/product_images/uploaded_images/surgery-room.png",
            "onHomePage" : 'product'
        },
        {
            "proName" : "produc1",
            "proPrice" : "₹2,000",
            "proDec" : "If you cannot provide a valid href, but still need the element to resemble a link,",
            "proImg" : "https://www.birkovaproducts.com/product_images/uploaded_images/surgery-room.png",
            "onHomePage" : 'product'
        },
        {
            "proName" : "produc1",
            "proPrice" : "₹2,000",
            "proDec" : "If you cannot provide a valid href, but still need the element to resemble a link,",
            "proImg" : "https://www.birkovaproducts.com/product_images/uploaded_images/surgery-room.png",
            "onHomePage" : 'product'
        },
        {
            "proName" : "produc1",
            "proPrice" : "₹2,000",
            "proDec" : "If you cannot provide a valid href, but still need the element to resemble a link,",
            "proImg" : "https://www.birkovaproducts.com/product_images/uploaded_images/surgery-room.png",
            "onHomePage" : 'product'
        },
        {
            "proName" : "produc1",
            "proPrice" : "₹2,000",
            "proDec" : "If you cannot provide a valid href, but still need the element to resemble a link,",
            "proImg" : "https://www.birkovaproducts.com/product_images/uploaded_images/surgery-room.png",
            "onHomePage" : 'product'

        },
        {
            "proName" : "produc1",
            "proPrice" : "₹2,000",
            "proDec" : "If you cannot provide a valid href, but still need the element to resemble a link,",
            "proImg" : "https://www.birkovaproducts.com/product_images/uploaded_images/surgery-room.png",
            "onHomePage" : 'product'
        },
        {
            "proName" : "produc1",
            "proPrice" : "₹2,000",
            "proDec" : "If you cannot provide a valid href, but still need the element to resemble a link,",
            "proImg" : "https://www.birkovaproducts.com/product_images/uploaded_images/surgery-room.png",
            "onHomePage" : 'product'
        },
        {
            "proName" : "produc1",
            "proPrice" : "₹2,000",
            "proDec" : "If you cannot provide a valid href, but still need the element to resemble a link,",
            "proImg" : "https://www.birkovaproducts.com/product_images/uploaded_images/surgery-room.png"
        }
    ],
    "subDec" : "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Velit, quae provident dolor consequatur amet.",
    "clientData" : [
        {
            "hosImg": `https://images.pexels.com/photos/10334732/pexels-photo-10334732.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260`,
            "hosName" : "Thana Hospital",
            "hosCity" : "Thane",
            "hosDec" : "Lorem, ipsum dolor sit amet consectetur adipisicing elit. Molestias doloremque iure rerum, molestiae ab quam delectus distinctio repellat, voluptates, aliquid non. Fugiat unde vitae, reprehenderit nisi sequi veniam molestiae est?",
        },
        {
            "hosImg": `https://images.pexels.com/photos/10334732/pexels-photo-10334732.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260`,
            "hosName" : "Thana Hospital",
            "hosCity" : "Thane",
            "hosDec" : "Lorem, ipsum dolor sit amet consectetur adipisicing elit. Molestias doloremque iure rerum, molestiae ab quam delectus distinctio repellat, voluptates, aliquid non. Fugiat unde vitae, reprehenderit nisi sequi veniam molestiae est?",
        },{
            "hosImg": `https://images.pexels.com/photos/10334732/pexels-photo-10334732.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260`,
            "hosName" : "Thana Hospital",
            "hosCity" : "Thane",
            "hosDec" : "Lorem, ipsum dolor sit amet consectetur adipisicing elit. Molestias doloremque iure rerum, molestiae ab quam delectus distinctio repellat, voluptates, aliquid non. Fugiat unde vitae, reprehenderit nisi sequi veniam molestiae est?",
        },{
            "hosImg": `https://images.pexels.com/photos/10334732/pexels-photo-10334732.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260`,
            "hosName" : "Thana Hospital",
            "hosCity" : "Thane",
            "hosDec" : "Lorem, ipsum dolor sit amet consectetur adipisicing elit. Molestias doloremque iure rerum, molestiae ab quam delectus distinctio repellat, voluptates, aliquid non. Fugiat unde vitae, reprehenderit nisi sequi veniam molestiae est?",
        },
    ],
    "footer": {
        "support": [
            {
                "name": "Online Help",
                "url": "product/"
            },
            {
                "name": "Customer Service",
                "url": "product/"
            },
            {
                "name": "Shipping FAQ",
                "url": "product/"
            },
            {
                "name": "Service Centres",
                "url": "product/"
            },
            {
                "name": "Warrenty",
                "url": "product/"
            },
            {
                "name": "Mi Exchange",
                "url": "product/"
            },
            {
                "name": "Bulk Order",
                "url": "product/"
            },
            {
                "name": "User Guide",
                "url": "product/"
            },
            {
                "name": "Laptop Drivers",
                "url": "product/"
            },
            {
                "name": "Mi Screen Protect",
                "url": "product/"
            },
            {
                "name": "Mi Extended Warranty",
                "url": "product/"
            }
    ],
    "shopAndLearn": [
            {
                "name": "Mi 10i",
                "url": "product/"
            },
            {
                "name": "Mi 10T Series",
                "url": "product/"
            },
            {
                "name": "Mi 11 Ultra",
                "url": "product/"
            },
            {
                "name": "Mi 11X",
                "url": "product/"
            },
            {
                "name": "Mi 11X Pro",
                "url": "product/"
            },
            {
                "name": "Redmi 8",
                "url": "product/"
            },
            {
                "name": "Redmi 9",
                "url": "product/"
            },
            {
                "name": "Redmi 9 Prime",
                "url": "product/"
            },
            {
                "name": "Redmi 9i",
                "url": "product/"
            },
            {
                "name": "Redmi 9A",
                "url": "product/"
            },
            {
                "name": "Redmi Note 10",
                "url": "product/"
            },
            {
                "name": "Redmi Note 10 Pro",
                "url": "product/"
            },
            {
                "name": "Redmi Note 10 Pro Max",
                "url": "product/"
            },
            {
                "name": "Redmi Note 9 Pro",
                "url": "product/"
            },
            {
                "name": "Redmi Note 9",
                "url": "product/"
            },
            {
                "name": "Redmi Note 9 Pro Max",
                "url": "product/"
            },
            {
                "name": "TVs",
                "url": "product/"
            },
            {
                "name": "Laptops",
                "url": "product/"
            }
    ],
    "retailStore": [
            {
                "name": "Mi Home",
                "url": "product/"
            },
            {
                "name": "Mi Authorised Stores",
                "url": "product/"
            }
    ],
    "aboutUS": [
            {
                "name": "Xioami",
                "url": "product/"
            },
            {
                "name": "Mediakit",
                "url": "product/"
            },
            {
                "name": "Culture",
                "url": "product/"
            },
            {
                "name": "User Agreement",
                "url": "product/"
            },
            {
                "name": "Privacy Policy",
                "url": "product/"
            },
            {
                "name": "Declarations",
                "url": "product/"
            },
            {
                "name": "Integrity & Compliance",
                "url": "product/"
            },
            {
                "name": "Smartphone Quality",
                "url": "product/"
            },
            {
                "name": "TV Quality",
                "url": "product/"
            },
            {
                "name": "Service Quality",
                "url": "product/"
            },
            {
                "name": "Environment",
                "url": "product/"
            },
            {
                "name": "Sitemap",
                "url": "product/"
            }
    ],
    "contactUs": [
            {
                "name": "Email",
                "url": "product/"
            },
            {
                "name": "Careers",
                "url": "product/"
            }
    ]
    }
 }

export default Data;