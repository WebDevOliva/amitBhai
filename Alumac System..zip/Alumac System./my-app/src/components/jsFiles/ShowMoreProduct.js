import React from 'react'
import '../cssFiles/showMoreProduct.css'

const ShowMoreProduct = ({show}) => {
    return (
        <>
            <div className="ShowMore" id={show}>

            </div>
        </>
    )
}

export default ShowMoreProduct 