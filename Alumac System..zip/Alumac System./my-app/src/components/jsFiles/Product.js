import React from 'react'
import '../cssFiles/product.css'
import ProCard from './ProCard'

const Product = ({proData,prokey}) => {
    return (
        <>
          <div className="proContainer">
              {
                proData.map((e,i) => {
                    if(i < prokey){
                      return(
                        <>
                            <ProCard proName={e.proName} proPrice={e.proPrice} proDec={e.proDec} proImg={e.proImg} path={e.onHomePage} index={i} />
                        </>
                    )
                    }
                })
              }
          </div>
        </>
    )
}

export default Product
