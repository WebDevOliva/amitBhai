import React from 'react'
import '../cssFiles/product.css'

const ProCard = ({proName,proPrice,proDec,proImg,index}) => {
    return (
        <>
           <div className="proCardBx">
                <div className="proCardBx-imgBx">
                    <img src={proImg} alt={`Product ${index}`} />
                </div>
                <div className="proCardBx-button">
                    <a href="/contact"><button>Contact Us</button></a>
                </div>
                <div className="proCardBx-contentBx">
                    <h1 className='proCardBx-contentBx__proName'>{proName}</h1>
                    <h3 className='proCardBx-contentBx__proPrice'>{proPrice}</h3>
                    <p className='proCardBx-contentBx__proDec'>{proDec}</p>
                </div>
           </div>
        </>
    )
}

export default ProCard
