import React, { useState } from 'react'
import { Link } from 'react-router-dom';
import '../cssFiles/navbar.css'
import Sidebar from './Sidebar';

const Navbar = ({web_logo,relative}) => {
    const [showSidebar,setSidebar] = useState(false);
    let toggleIcon = (showSidebar != true) ? <ion-icon name="menu-outline"></ion-icon> : <ion-icon name="close-outline" id="closeMenu"></ion-icon>;
    return (
        <>
            <div className="navbar" id={relative}>
                <Link to={`/`} className='Link'><a><img src={web_logo} alt="website logo" className="navbar-website__logo"/></a></Link>
                <Link to={`/`} className='Link'><a className="web__logo"><span>Alumac</span> System.</a></Link>
                <div className="navbar__rightBx">
                <Link to={`/home`} className='Link'> <a className='navbar__rightBx-navLinks'>Home</a> </Link>
                <Link to={`/aboutUs`} className='Link'><a className='navbar__rightBx-navLinks'>About Us</a></Link>
                <Link to={`/product`} className='Link'><a className='navbar__rightBx-navLinks'>Product</a></Link>
                <Link to={`/client`} className='Link'><a className='navbar__rightBx-navLinks'>Our Client</a></Link>
                <Link to={`/contact`} className='Link'><a className='navbar__rightBx-navLinks'>Contact Us</a></Link>
                </div>
                <div className="navbar__toggle" onClick={() => {setSidebar(!showSidebar)}}>
                    {toggleIcon}
                </div>
            </div>
            <Sidebar show={(showSidebar === true) ? 'show' : 'hide'} />
        </>
    )
}

export default Navbar
