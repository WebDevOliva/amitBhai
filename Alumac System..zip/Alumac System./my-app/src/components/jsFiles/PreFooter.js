import React from 'react'
import '../cssFiles/footer.css'
const PreFooter = ({name}) => {
    return (
        <>
            <a href="">{name}</a>
        </>
    )
}

export default PreFooter
