import React from 'react'
import CustomButton from '../components/jsFiles/CustomButton';
import Footer from '../components/jsFiles/Footer';
import Heading from '../components/jsFiles/Heading';
import Home from '../components/jsFiles/Home';
import Navbar from '../components/jsFiles/Navbar';
import NewArrive from '../components/jsFiles/NewArrive';
import Product from '../components/jsFiles/Product';
import Services from '../components/jsFiles/Services';
import Subscribe from '../components/jsFiles/Subscribe';
import Testimonial from '../components/jsFiles/Testimonial';
import Data from '../Data/Data'
import './style.css'

const MainHome = ({producShow,clientShow}) => {
    return (
        <>
         <Navbar key={'0'} web_logo={Data.webLogo}/>
         <Home key={Data.homeData.key} details={Data.homeData} />
         <Heading heading={`Why Shop With Us`} headSpan={null} />
         <Services key={Data.serviceData.values} details={Data.serviceData} />
         <NewArrive   data={Data.newArrivel}/>
         <Heading heading={`Our`} headSpan={` Product`}/>
         <Product proData={Data.product} prokey={producShow}/>
         <div className="div">
            <CustomButton Data={'View More'} link={'product'}/>
         </div>
         <Subscribe data={Data.subDec}/>
         <Heading heading={`Our`} headSpan={` Client`}/>
         <Testimonial data={Data.clientData} clientKey={clientShow}/>
         <div className="div">
            <CustomButton Data={'View More'} link={'client'}/>
         </div>
         <Footer data={Data.footer}/>
        </>
    )
}

export default MainHome
