import React from 'react'
import Footer from '../components/jsFiles/Footer'
import Navbar from '../components/jsFiles/Navbar'
import Data from '../Data/Data'
import Product from '../components/jsFiles/Product'
import Heading from '../components/jsFiles/Heading'
const MainProduct = ({producShow}) => {
    return (
        <>
            <Navbar relative={'relative'} web_logo={Data.webLogo}/>
            <Heading heading={`Our`} headSpan={`Product`} />
            <Product proData={Data.product} prokey={producShow}/>
            <Footer data={Data.footer}/>
        </>
    )
}

export default MainProduct
